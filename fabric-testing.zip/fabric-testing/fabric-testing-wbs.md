# Work Breakdown Structure: Fabric Testing and Release Governance

Companion to the executive roadmap. Structured for Azure DevOps under the **Scrum** process template: Epic, Feature, Product Backlog Item, Task.

**Import file:** `fabric-testing-wbs-ado-import.csv` (102 rows: 5 epics, 15 features, 53 product backlog items, 29 tasks).

---

## 1. Scope and assumptions

| | |
|---|---|
| Provisional start | 31 August 2026, conditional on closure of the existing technical debt backlog |
| Cadence | Scrum, two-week sprints, 8 sprints to 18 December 2026 |
| Resourcing | One engineer, Copilot-assisted delivery |
| Allocation | **Unconfirmed.** Estimates assume substantial dedicated capacity. If this runs alongside business as usual, extend proportionally |
| In scope | Automated testing framework, source control integration, CI/CD |
| Out of scope | Dataflow Gen2 migration to notebooks; refactoring inline notebook logic into shared transformation components |

### What the out-of-scope items cost you

Excluding the refactor means **unit testing is not achievable within this program**. Transformation logic that lives inline in notebook cells cannot be tested in isolation, so all correctness assurance happens at the data layer after execution rather than at the code layer before it. CI in this program therefore delivers linting, secret scanning, and deployment automation, not unit test execution. The test pyramid stays inverted by design. This is a defensible position at this scale; it is not a defensible position to leave undocumented.

Excluding the Dataflow Gen2 migration means those two tables are covered by output assertions only (F3.2). Failures will be detected but not localized, and the tables remain outside source control coverage if the item type is not fully supported by Git integration (F1.1 records this).

---

## 2. Azure DevOps import mechanics

Four corrections worth applying before you import, each of which will otherwise cost you a failed import or a flat backlog.

**Work item type naming.** You asked for user stories. The Scrum process template does not have that type. <cite index="38-1">Agile uses User Story; Scrum uses Product Backlog Item; CMMI uses Requirement.</cite> The CSV uses `Product Backlog Item`. If your project is actually on the Agile template, find and replace that string before importing.

**Hierarchy comes from indented title columns, not a parent field.** <cite index="38-1">Parent-child links are created by indenting the title columns, and no other link type can be specified during import.</cite> <cite index="34-1">A Parent ID column is ignored outright, so items imported that way arrive with no parent.</cite> The CSV uses `Title 1` through `Title 4` with exactly one populated per row.

**State cannot be set on import.** <cite index="39-1">Imported work items default to New, and changing state requires importing, exporting, editing state, then reimporting.</cite> The State column is deliberately absent.

**Sprint is carried in Tags, not Iteration Path.** <cite index="39-1">Area and Iteration default to the top-level node unless explicitly specified.</cite> An explicit iteration path fails the import if the node does not already exist in the project. Tags such as `Sprint-3` import cleanly regardless, and you can bulk-assign iteration paths in the portal afterwards.

**Before importing:** export one existing work item of each type from your project to CSV and compare column names. <cite index="38-1">Field availability differs by process template and Azure DevOps version, so verifying against an export is the documented prerequisite.</cite> `Effort` is populated for product backlog items only; `Priority` is omitted on tasks because the Scrum task type does not reliably expose it.

*Verified against learn.microsoft.com/en-us/azure/devops/boards/queries/import-work-items-from-csv, retrieved 5 August 2026.*

---

## 3. Dependency model

### External dependencies

| ID | Dependency | Needed by | Consequence if late |
|---|---|---|---|
| D0 | Technical debt backlog closed | Before S1 | Start slips day for day. Largest single schedule risk |
| D1 | GitHub Copilot licensing and enablement | S1 | Estimates assume Copilot-assisted delivery. Note the coupling: Copilot is only useful against code in a repository, so D1 delivers no value until F1.1 completes |
| D2 | Service principal registration and secret store access | S1 | Blocks F1.2 entirely, therefore blocks gate G1 |
| D3 | Named independent approver for pull request review | S2 | Branch policy cannot require a reviewer. Segregation of duties remains unevidenced |
| D4 | Representative non-production data subset | S4 | Blocks idempotency validation (2.3.2) and gate G3. Validation continues in production |
| D5 | Capacity headroom for test workspace execution | S4 | Test runs contend with production workloads |

### Inter-workstream dependencies

| Item | Depends on | Why |
|---|---|---|
| F1.1 Git integration | D0, D2 | Nothing starts until prior work clears and identity is provisioned |
| F1.2 Automated deployment | F1.1, D2 | Deployment needs a branch topology to deploy from |
| F1.3 Build validation | F1.2 | Validation pipelines attach to an existing pipeline definition |
| F1.4 Workflow enablement | F1.2, F1.3, D1, D3 | Manual promotion cannot be retired until the automated path is proven and reviewed |
| F2.1 Results and config store | F1.2 | Configuration must deploy through the same controlled path as code, or the gate framework is itself an ungoverned change |
| F2.2 Assertion engine | F2.1 | Engine reads configuration and writes results |
| F2.3 Gold integrity | F2.2, D4 | D4 applies to idempotency validation only. The remaining checks run without it |
| F3.1 Bronze contracts | F2.2 | Contracts are expressed as engine checks |
| F3.2 Silver coverage | F2.2 | Same |
| F3.3 Observability | F2.1, F3.1 | Reporting needs a populated results store and meaningful coverage |
| F4.1 Semantic test harness | F2.3 | **Sequencing matters here.** Reconciling measures against gold tables that are not yet gated produces failures caused by upstream data rather than by the model, which trains the team to ignore the harness |
| F4.2 Pre-publish gate | F4.1, F1.2 | The gate is part of a release process that must already be automated |
| F5.1 Control documentation | E1 to E4 operating | You document controls that exist, not controls that are planned |
| F5.2 Operational readiness | F2.2 | Runbooks describe quarantine and blocking semantics defined in the engine |
| F5.3 Program close | All | Assessment against the baseline requires the baseline to be met or explicitly missed |

### Critical path

```
D0 -> D2 -> F1.1 -> F1.2 -> F2.1 -> F2.2 -> F2.3 -> F3.1 -> F3.3 -> F5.1 -> F5.3
```

E4 is the only workstream with float. It depends on F2.3 but not on E3, so it can absorb a one-sprint slip without moving the program end date. Everything else is on the path.

---

## 4. Sprint allocation

| Sprint | Window | Features in flight | Gate |
|---|---|---|---|
| S1 | 31 Aug to 11 Sep | F1.1, F1.2 | |
| S2 | 14 Sep to 25 Sep | F1.2, F1.3, F1.4 | **G1** Manual promotion retired |
| S3 | 28 Sep to 09 Oct | F2.1, F2.2 | |
| S4 | 12 Oct to 23 Oct | F2.2, F2.3 | **G2** Gold gates live in non-production |
| S5 | 26 Oct to 06 Nov | F3.1, F3.2 | |
| S6 | 09 Nov to 20 Nov | F3.2, F3.3, F4.1 | **G3** Production-only validation retired |
| S7 | 23 Nov to 04 Dec | F4.1, F4.2, F5.2 | **G4** Manual DAX sign-off retired |
| S8 | 07 Dec to 18 Dec | F5.1, F5.2, F5.3 | **G5** Evidence pack producible on demand |

---

## 5. Work breakdown structure

Tasks are populated for E1 and E2 (sprints 1 to 4). Later epics carry product backlog items only, to be broken into tasks at sprint planning rather than estimated in detail four months out.

### E1 Source control and release governance

#### F1.1 Fabric Git integration

- **PBI** Branching strategy and workspace-to-branch topology defined `3 pts` <br>`Sprint-1`
  - Task: Document branch model and promotion flow
  - Task: Map dev, test and production workspaces to branches
  - Task: Review topology with named approver
- **PBI** Dev workspace connected to source control `5 pts` <br>`Sprint-1`
  - Task: Create repository and folder structure
  - Task: Connect workspace and resolve initial sync conflicts
  - Task: Commit existing workspace items as baseline
- **PBI** Item-type coverage baseline documented `3 pts` <br>`Sprint-1`
  - Task: Inventory all workspace item types in scope
  - Task: Verify source control support per item type
  - Task: Record unsupported items and manual handling procedure
- **PBI** Branch policies and pull request review gate configured `3 pts` <br>`Sprint-2`
  - Task: Configure required reviewer policy
  - Task: Link build validation policy to protected branch

#### F1.2 Automated deployment

- **PBI** Environment parameterization defined `5 pts` <br>`Sprint-1`
  - Task: Inventory environment-specific values across all items
  - Task: Author parameter file and validate substitution
- **PBI** Service principal registration and secret handling established `3 pts` <br>`Sprint-1`
  - Task: Register application and grant workspace permissions
  - Task: Store credentials in secret store
  - Task: Configure pipeline variable group
- **PBI** Dev to test deployment pipeline operational `5 pts` <br>`Sprint-2`
- **PBI** Test to production deployment pipeline with approval gate `5 pts` <br>`Sprint-2`
- **PBI** Rollback runbook authored and rehearsed `3 pts` <br>`Sprint-2`
  - Task: Document code and data rollback procedures separately
  - Task: Rehearse rollback in test and record elapsed time

#### F1.3 Build validation

- **PBI** Static analysis and formatting checks on notebook source `3 pts` <br>`Sprint-2`
- **PBI** Secret scanning in pull request validation `2 pts` <br>`Sprint-2`
- **PBI** Pull request build validation pipeline wired to branch policy `3 pts` <br>`Sprint-2`

#### F1.4 Developer workflow enablement

- **PBI** Copilot-assisted local editing workflow documented `2 pts` <br>`Sprint-2, Dependency-D1`
- **PBI** Manual portal promotion decommissioned `2 pts` <br>`Sprint-2, Gate-G1`

### E2 Data quality gate framework

#### F2.1 Results and configuration store

- **PBI** Results table schema, partitioning and retention defined `3 pts` <br>`Sprint-3`
  - Task: Create results table and validate write path
  - Task: Define retention period with compliance input
- **PBI** Check configuration format and storage location established `3 pts` <br>`Sprint-3`
- **PBI** Configuration validated automatically on deployment `3 pts` <br>`Sprint-3`

#### F2.2 Assertion engine

- **PBI** Engine core: configuration load, evaluation, result persistence `8 pts` <br>`Sprint-3`
  - Task: Implement configuration loader and validation
  - Task: Implement threshold and band evaluation modes
  - Task: Implement result persistence before failure signalling
- **PBI** Severity model and quarantine path for row-level failures `5 pts` <br>`Sprint-3`
  - Task: Define blocking, quarantine and warning semantics
  - Task: Implement reject table routing and reject accounting
- **PBI** Failure signalling and orchestration blocking behaviour `3 pts` <br>`Sprint-3`
- **PBI** Engine self-validation fixtures `3 pts` <br>`Sprint-4`

#### F2.3 Gold layer integrity

- **PBI** Merge key uniqueness and null key guards on all gold tables `5 pts` <br>`Sprint-4`
  - Task: Implement key cardinality guard
  - Task: Implement null key guard
  - Task: Apply across gold table inventory
- **PBI** Idempotency validation in non-production `5 pts` <br>`Sprint-4, Dependency-D4`
- **PBI** Referential integrity checks from fact to dimension `3 pts` <br>`Sprint-4`
- **PBI** Table constraints applied to gold key columns `3 pts` <br>`Sprint-4`
  - Task: Verify non-Spark writers still succeed against constrained tables
- **PBI** Existing inline duplicate checks migrated into the engine `3 pts` <br>`Sprint-4`
- **PBI** Blocking gates enabled across gold layer in test `2 pts` <br>`Sprint-4, Gate-G2`

### E3 Source and pipeline coverage

#### F3.1 Bronze source contracts

- **PBI** Schema fingerprint baseline captured per source table `3 pts` <br>`Sprint-5`
- **PBI** Schema drift detection with additive and breaking classification `5 pts` <br>`Sprint-5`
- **PBI** Freshness checks per source `3 pts` <br>`Sprint-5`
- **PBI** Volume band checks per source `3 pts` <br>`Sprint-5`

#### F3.2 Silver coverage

- **PBI** Cleansing rule assertions `5 pts` <br>`Sprint-5`
- **PBI** Row accounting reconciliation from bronze to silver `3 pts` <br>`Sprint-6`
- **PBI** Output checks for low-code sourced tables `3 pts` <br>`Sprint-6`

#### F3.3 Observability and reporting

- **PBI** Quality report over the results store `5 pts` <br>`Sprint-6`
- **PBI** Alerting on blocking failures `3 pts` <br>`Sprint-6`
- **PBI** Coverage tracking for tables with and without checks `3 pts` <br>`Sprint-6`
- **PBI** Non-production validation adopted as the default practice `2 pts` <br>`Sprint-6, Gate-G3`

### E4 Semantic model release validation

#### F4.1 Test harness

- **PBI** Test runner and test definition format `5 pts` <br>`Sprint-6`
- **PBI** Measure reconciliation tests against gold tables `5 pts` <br>`Sprint-7`
- **PBI** Known-good anchor tests for frozen historical periods `3 pts` <br>`Sprint-7`

#### F4.2 Pre-publish gate

- **PBI** Harness wired into the semantic model release process `5 pts` <br>`Sprint-7`
- **PBI** Model rule scoring at warning severity `2 pts` <br>`Sprint-7`
- **PBI** Row-level security coverage decision documented `2 pts` <br>`Sprint-7, Conditional-Scope`
- **PBI** Manual DAX sign-off decommissioned `2 pts` <br>`Sprint-7, Gate-G4`

### E5 Audit evidence and operational readiness

#### F5.1 Control documentation

- **PBI** Control narrative mapping gates to control objectives `5 pts` <br>`Sprint-8`
- **PBI** Evidence extraction queries and retention policy `3 pts` <br>`Sprint-8`
- **PBI** Evidence pack walkthrough with compliance stakeholder `2 pts` <br>`Sprint-8, Gate-G5`

#### F5.2 Operational readiness

- **PBI** Triage runbook for blocked runs and quarantined rows `5 pts` <br>`Sprint-7`
- **PBI** Escalation path and named backup established `2 pts` <br>`Sprint-8, Risk-BusFactor`
- **PBI** Handover documentation and knowledge transfer session `5 pts` <br>`Sprint-8, Risk-BusFactor`

#### F5.3 Program close

- **PBI** Coverage and maturity assessment against baseline `3 pts` <br>`Sprint-8`
- **PBI** Residual risk register published `3 pts` <br>`Sprint-8`

---

## 6. Residual coverage after program close

| Gap | Why it remains | Mitigation in place |
|---|---|---|
| No unit tests on transformation logic | Refactor of inline notebook code is out of scope | Data-layer assertions catch incorrect output, though not the specific line that produced it |
| Low-code sourced tables partially covered | Migration out of scope | Output assertions only (3.2.3). Failure detected, not localized |
| Row-level security testing | Depends on a vendor preview capability | Recorded as conditional scope (4.2.3). Remains manual if the capability does not reach general availability |
| Segregation of duties | Single-engineer delivery | Dependent on D3. If no independent approver is named, a compensating control must be documented in the control narrative (5.1.1) |
| Performance and load testing | Not requested, not scoped | None. Flag if the audit scope includes availability or capacity controls |

---

## 7. Estimation basis and confidence

Story points are relative, calibrated so that a 3 is roughly two focused days for one engineer familiar with the estate. Total is 186 points across 8 sprints, which implies roughly 23 points per sprint. That is a high single-person velocity and it is the assumption most likely to be wrong.

| Element | Confidence | Basis |
|---|---|---|
| CSV import mechanics | **High** | Verified against current Microsoft Learn documentation, 5 August 2026 |
| WBS completeness | **Moderate to high** | Derived from the stated landscape. Gaps most likely in areas not yet described: existing orchestration, alerting infrastructure, and current workspace topology |
| Dependency ordering | **High** | Technical dependencies, not judgement calls, with the exception of source control before quality gates which is a deliberate risk decision |
| Sprint allocation | **Low to moderate** | Depends entirely on unconfirmed allocation (D-D). Treat sprint boundaries as sequence, not schedule, until that is fixed |
| Program end date | **Low** | Compounded by D0. Do not communicate 18 December as committed |

Re-baseline once D0 has a firm completion date and allocation is confirmed. Until then this is a sequence with indicative dates attached, and it should be presented that way.
