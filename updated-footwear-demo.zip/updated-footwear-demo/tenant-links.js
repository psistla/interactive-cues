/* ─────────────────────────────────────────────────────────────
   TENANT LINKS — paste your Fabric deep links between the quotes.

   Any entry left empty renders as a greyed-out "link not set" chip
   in msft-deck.html, so an unfilled slot never looks like a broken
   link during the meeting. Fill only what you plan to open live.

   To get a deep link: open the item in Fabric, copy the browser URL.

   This is a .js file rather than .txt on purpose — a double-clicked
   HTML page can't fetch() a local text file (browsers block it on
   file://), but it can load a script. Edit it in Notepad exactly
   like a text file; just keep the quotes and commas.
   ───────────────────────────────────────────────────────────── */

const TENANT_LINKS = {

  /* ── Slide 1 · What I built ────────────────────────────────── */
  lakehouse:              "",   // lh_footwear — 7 managed delta tables
  semanticModel:          "",   // sm_footwear_sustainability — Direct Lake
  ontology:               "",   // FootwearSustainabilityOntology
  dataAgent:              "",   // data agent, ontology as sole source

  /* ── Slide 2 · Where it shines ─────────────────────────────── */
  shortcutBinding:        "",   // Finding 1 — shortcut bound, returned rows
  securedLakehouseBinding:"",   // Finding 2 — OneLake-secured lakehouse, bound + charts
  generatedOntology:      "",   // the as-generated ontology, before manual renames

  /* ── Slide 3 · Where it fails ──────────────────────────────── */
  agentQueryBaseline:     "",   // original run — ranked by raw column, no traversal
  agentQueryGroupBy:      "",   // re-run with `Support group by in GQL` added
  agentInstructions:      "",   // the agent's instructions pane showing the added line
  entityTypeDetails:      "",   // Supplier entity type — properties, no Carbon Intensity

};

/* Used by both msft-deck.html and build-msft-pptx.js.
   Node needs this line; the browser ignores it. */
if (typeof module !== "undefined") { module.exports = { TENANT_LINKS }; }
