# Spike findings — Fabric Ontology, run 2026-08-05, validated against Learn 2026-08-05

For the Microsoft Fabric IQ / Ontology meeting, Thursday 2026-08-06 PM.

**Coverage: 3 of 8 planned tests run.** Say that number out loud.

## Sources checked (all live 2026-08-05)

| Page | Learn last updated |
|---|---|
| [Bind data](https://learn.microsoft.com/en-us/fabric/iq/ontology/how-to-bind-data) | 2026-06-22 |
| [What is ontology (preview)?](https://learn.microsoft.com/en-us/fabric/iq/ontology/overview) | 2026-07-21 |
| [Generating an ontology from a semantic model](https://learn.microsoft.com/en-us/fabric/iq/ontology/concepts-generate) | 2026-05-14 |
| [Ontology FAQ](https://learn.microsoft.com/en-us/fabric/iq/ontology/resources-frequently-asked-questions) | 2026-06-02 |
| [Troubleshooting ontology](https://learn.microsoft.com/en-us/fabric/iq/ontology/resources-troubleshooting) | 2026-06-22 |

---

## Validation verdicts

| # | Finding | Verdict |
|---|---|---|
| 1 | Internal OneLake shortcut binds and returns rows | **HOLDS — contradicts docs** |
| 2 | OneLake-security-enabled lakehouse binds and renders | **HOLDS — contradicts docs in three places** |
| 3 | Import mode generates but doesn't bind | **DOWNGRADED — fully documented, we hadn't read the page** |
| 4 | NL layer used a raw column, didn't traverse | **STRONGEST — cause isolated 2026-08-06; the documented mitigation was applied and did nothing** |
| 5 | No re-sync from semantic model | **HOLDS — supported by docs, but state it as "regenerate is the only path"** |

---

## Finding 1 — Internal OneLake shortcuts bind. HOLDS.

**Observed:** shortcut in the lakehouse to another lakehouse's table. Appeared in the
picker, bound, saved, query returned rows.

**Docs, [Bind data](https://learn.microsoft.com/en-us/fabric/iq/ontology/how-to-bind-data),
repeated verbatim on [concepts-generate](https://learn.microsoft.com/en-us/fabric/iq/ontology/concepts-generate):**

> Ontology only supports **managed** lakehouse tables (located in the same OneLake directory
> as the lakehouse), not **external** tables that show in the lakehouse but reside in a
> different location.

The parenthetical is precise and it covers your case exactly: a shortcut *shows in the
lakehouse* and *resides in a different location*. **Drop the "the word external is ambiguous"
hedge from the earlier draft** — it isn't ambiguous, and your result contradicts it directly.

[Troubleshooting](https://learn.microsoft.com/en-us/fabric/iq/ontology/resources-troubleshooting)
names the expected symptom as *"Entity type details shows no data."* You got data.

**Still untested:** external shortcuts to ADLS Gen2 / S3.

---

## Finding 2 — OneLake security works as a binding source. HOLDS, and it's your strongest.

**Observed:** OneLake security enabled on the lakehouse; binding succeeded, instances showed
rows, overview rendered charts.

**Docs say the opposite in three separate places:**

1. Prerequisites — lakehouse tables must be managed and *"do not have OneLake security enabled"*
2. Limitations — *"You can't use lakehouses with OneLake security enabled as data sources for bindings."*
3. Troubleshooting — *"Lakehouse not available as data source when creating a binding → Check to make sure OneLake security isn't enabled."*

The documented symptom is that the lakehouse **doesn't appear in the picker at all.** Yours
appeared, bound, and served data.

**Say "three places, two pages" — not "three pages."** Verified 2026-08-05: prerequisites and
limitations both live on *Bind data*; the third is on *Troubleshoot ontology*. The earlier
draft said three pages and that is wrong.

**The open question, still the best in the deck.** You tested as workspace admin, who sees
every row regardless. Whether OneLake row and column restrictions are *enforced* through the
ontology or read straight through was not tested.

> "I bound an ontology to a OneLake-security-enabled lakehouse and got rows. Your docs say
> that lakehouse shouldn't even appear in the picker. I was admin, so I couldn't tell whether
> the restrictions were enforced or bypassed. Which is it?"

---

## Finding 3 — Import mode. DOWNGRADED. The docs are right and more thorough than we were.

[concepts-generate](https://learn.microsoft.com/en-us/fabric/iq/ontology/concepts-generate)
carries a support matrix we had not read:

| Feature | Import | Direct Lake | DirectQuery |
|---|---|---|---|
| Generating entity type definitions | Supported | Supported | Supported |
| Generating entity type **bindings** | **Not supported** | Supported *(only if backing lakehouse workspace has inbound public access enabled)* | Not supported |
| **Querying** data using bindings | **Not supported** | Supported **(without measures and calculated columns)** | Not supported |

And troubleshooting names your exact experience:

> The ontology item is created but entity types have no data bindings → Ontology data binding
> is not supported for source semantic models in **Import mode**.

**"Generation succeeds, binding fails" is documented behavior, not a discovery.** Do not
present it as one. The only piece that survives is narrow and still worth 30 seconds:

> The error text — *"Entity type 'dim_customer' does not have a non-time-series mapping
> configured"* — names a symptom, not the documented cause. It never says "import mode."
> A builder who hits it at query time has nothing to search for.

**Correction to the earlier draft:** I wrote that "non-time-series" appears nowhere in the
docs. It does — the Bind data page says *"This non-timeseries binding defines the unique
entity type instances."* Different hyphenation, same term. **Do not claim the vocabulary is
undocumented.** The accurate claim is that the error doesn't reference the mode that caused it.

---

## Finding 4 — REFRAMED, and it's now the best finding you have

**Observed:** asked *"Which factories produce for our highest-intensity suppliers?"* The agent
ranked factories by `grid_kg_co2e_per_kwh` — a raw Factory column — never traversed the
OrderLine relationship, and described that Factory-only column as belonging to Supplier.
Verified exactly against source CSVs (run 1 = ranks 1–2, runs 2–3 = ranks 1–10, order
differences fall inside exact ties at 0.75 and 0.63).

### The docs explain the mechanism — and it's worse than "it picked the wrong one"

From the support matrix above: querying via bindings in Direct Lake mode is

> **Supported (without measures and calculated columns)**

**Measures don't cross into the ontology at all.** `Carbon Intensity` was never available.
The agent didn't choose a raw column over your defined measure — **your defined measure was
gone, and nothing said so.**

That reframes the finding onto the product's core claim. The ontology is sold as *"a shared,
machine-understandable vocabulary of your business."* The business definitions — the measures
where the meaning actually lives — stay behind in the semantic model, and the NL layer answers
anyway using whatever raw column has a similar-sounding name.

This also resolves the hidden-measures-table question. Hidden objects are excluded
(troubleshooting: *"the tables in the semantic model are visible (not hidden)"*), but it
wouldn't have mattered — measures aren't supported either way.

### Two documented mitigations. One applied — it changed nothing.

Both from [troubleshooting](https://learn.microsoft.com/en-us/fabric/iq/ontology/resources-troubleshooting),
"ontology as data agent source":

1. > Query results don't aggregate correctly → There's a **known issue** affecting aggregation
   > in queries. To enable better aggregation, add the instruction `Support group by in GQL`
   > to the agent's instructions.
2. > Query results are vague or generic → make sure entity and relationship names are
   > meaningful and **documented** in the ontology.

You ran with **no agent instructions and no property descriptions**, deliberately — the right
call for an unaided baseline.

**`Support group by in GQL` was added to the agent instructions and the query re-run.
The answer did not change — same ten factories, same ranking, same substituted column.**

**Correction, 2026-08-06.** An earlier note in this file recorded the re-run as "aggregation
fixed, measure still absent." That was wrong. The baseline runs 2–3 already returned ranks
1–10, so a ten-item result after the instruction was read as an aggregation fix when it was
the identical output. Nothing was repaired.

| # | Observed | Did the group-by instruction fix it? |
|---|---|---|
| a | Ranked by raw `grid_kg_co2e_per_kwh` instead of the `Carbon Intensity` measure | **No.** |
| b | Never traversed the OrderLine relationship to aggregate per supplier | **No.** Same ten items as baseline. |
| c | Described a Factory-only column as belonging to Supplier | **No.** Same answer. |

**The strong version is now simpler and it is true:** *"I applied your documented workaround
and the answer didn't change."* Their published mitigation for this exact symptom does not
mitigate it.

### RESOLVED 2026-08-06 — cause A confirmed, cause B eliminated

Two explanations were open. The isolating test was run:

| | Cause | Prediction | Result |
|---|---|---|---|
| **A** | **Documented.** concepts-generate support matrix: Direct Lake *"Querying data using bindings: Supported (without measures and calculated columns)."* Measures excluded by design, sync or no sync. | Measure still absent. | **CONFIRMED** |
| **B** | **Lifecycle.** Measures postdated generation and there is no re-sync (Finding 5), so nothing picked them up. | Measure appears. | **ELIMINATED** |

A fresh ontology was generated from the same semantic model **with the measures already in
place**, and the factory question re-asked through the agent against it. **Same substituted
answer.** The measures were present at generation time and still did not reach the query path.

**Consequence for the room: drop the lifecycle caveat.** The talk track previously offered
"two mechanisms, one observation, I didn't isolate them" as an honest side note. That
concession is no longer accurate and giving it away weakens the finding. One mechanism,
isolated by experiment.

**What the fresh ontology did show — hold this in reserve, don't lead with it.** The measures
table came across as its **own entity type with no instances**, and the data agent did not list
measures under that ontology as a source at all. Two reasons not to put it on a slide: a
measures-only table carries few or no rows of its own, so an empty entity type may be expected
rather than defective; and the hidden-table exclusion is a second possible explanation. The
claim that survives scrutiny is the answer the agent gave, not the shape of the entity type.

### The question for the room

> "Measures don't come across from the semantic model, so my definition of Carbon Intensity
> wasn't in the ontology. The agent answered anyway, using a raw column with a similar name,
> and told me that column belonged to a different entity type. How should an ontology signal
> that a business definition is missing rather than substituting for it?"

---

## Finding 5 — No re-sync. HOLDS, restate it.

**Observed:** updated the semantic model, could not find a way to pull changes into the
existing ontology.

**Docs support this indirectly rather than stating it.** Troubleshooting repeatedly says
*"Resolve data issues and **regenerate** the ontology"* — regeneration, never re-sync. The
[FAQ](https://learn.microsoft.com/en-us/fabric/iq/ontology/resources-frequently-asked-questions)
confirms:

> Does ontology (preview) support ontology management like versioning? **No, versioning isn't
> currently available.**

concepts-generate also lists manual post-generation work: bind time series data, *"review
entity type keys and add any that are missing,"* bind relationship types, review everything.

> "Generation is one-time. The documented fix for any structural change is regenerate — which
> discards the entity renames, key definitions, and relationship bindings your own docs tell
> me to do by hand afterward. And there's no versioning to fall back on. The layer that
> defines my business has no lifecycle."

---

## Build note

Both your runbooks say "set key property `id` on each." `fact_order_line` has no `id` column
— OrderLine's key is `order_line_id`. Worth knowing: concepts-generate lists *"review entity
type keys and add any that are missing"* as an expected manual step, so the product behaved as
documented. The bug is in the runbooks. Fix them.

Also from concepts-generate, a confound worth checking before you demo: Fabric Graph doesn't
support the `Decimal` type and returns **null** for those properties on all queries. Your
money columns are the risk.

---

## What was not tested

| Test | Status |
|---|---|
| Second static binding per entity type | not run |
| Column name containing a space | not run |
| Versioning / rollback | not run (FAQ confirms absent) |
| Manual refresh staleness | not run |
| Renaming a bound table | not run |
| External shortcuts (ADLS Gen2 / S3) | not run |
| OneLake security **enforcement** under a restricted identity | not run |
| Agent re-run with `Support group by in GQL` | **run — answer unchanged, workaround had no effect** |
| Fresh ontology generated with measures already in the model | **run 2026-08-06 — same substituted answer. Cause A confirmed, B eliminated.** |

---

## Revised deck

**Dead:** "it says no copying then forces copying" (shortcuts bind) and "governance is the
differentiator and it can't read governed storage" (secured lakehouse binds).

**Also dead:** import mode as a discovery. It's in their support matrix.

**The three beats:**

1. **Two documented limitations don't reproduce.** Shortcuts bind. OneLake-security-enabled
   lakehouses bind, render instances, and serve charts — while three separate pages say the
   lakehouse shouldn't even appear in the picker. Either the docs are stale or something
   shipped without them.
2. **Measures don't reach the ontology, and the NL layer substitutes silently.** Verified
   end to end: the defined measure was absent, a similarly-named raw column was used instead,
   and the explanation attributed the column to the wrong entity type. **Then two corrective
   attempts, both of which changed nothing** — their own documented workaround
   (`Support group by in GQL`), and a fresh ontology generated with the measures already in
   the model. Three runs, one answer. The workaround doesn't mitigate the symptom it's
   published against, and the cause is the documented Direct Lake exclusion, now isolated
   rather than assumed.
3. **Two open questions.** Is OneLake security enforced through the ontology or read through?
   And how should an ontology signal a missing business definition instead of substituting
   for it?

Slides 2–3 (competitive position) unaffected — see `msft-competitive-position.md`.

**Posture:** you verified their product against their own documentation and found both
directions of drift. That is a gift to a preview team, and it earns everything critical you
say afterward.

---

## Where this stands — session close 2026-08-05

### Built in the tenant tonight

| Layer | State |
|---|---|
| Lakehouse | 7 clean CSVs as managed delta tables |
| Semantic model | Direct Lake, all tables, 6 relationships, measures added, **measures table hidden** |
| Ontology | `FootwearSustainabilityOntology` — generated, renamed, keys set (OrderLine = `order_line_id`), 4 relationships bound via `fact_order_line` |
| Data agent | Ontology as sole source, **no instructions** |
| Throwaway lakehouse | Used for the OneLake security test |
| Report | **Not built.** Demo runbook Ch.4 was never done — it isn't needed for the meeting. |

### Open threads, in priority order

1. ~~Re-run the agent question with `Support group by in GQL`.~~ **Done — no effect at all.**
   Finding 4 survives its own documented workaround, and the workaround itself is now a finding.
2. ~~Slides 1 and 4.~~ **Written 2026-08-05 — `msft-slides-1-and-4.md`.** Open = the spike
   and the three beats; close = the four laddered asks. Slides 2–3 unchanged.
   Note: `deck.pptx` and `short-deck.pptx` on disk are the *client* deck from 2026-07-31 and
   still carry the two dead claims. Nothing built has been regenerated since.
3. ~~**Second ontology from the same semantic model.**~~ **Done 2026-08-06.** Generated with
   measures already in the model; agent re-asked; same substituted answer. Cause A confirmed,
   cause B eliminated. The measures table arrived as an entity type with no instances and the
   agent didn't list measures under it — reserve material, confounded, not slide material.
4. **Five untested limits** — second static binding, column-with-space, versioning, refresh
   staleness, rename. All optional; the coverage number matters more than closing them.
5. **`Decimal` null risk** — verify before any demo. Money columns are the exposure.

### Corrections made during the session — don't reintroduce

- OrderLine's key is `order_line_id`, not `id`. Both runbooks still carry the wrong value.
- "External" in the binding docs is **not** ambiguous — it explicitly covers shortcuts.
- "non-time-series" **does** appear in the docs. Don't claim the vocabulary is undocumented.
- Import-mode binding failure is **documented**, not a discovery.
- **`Support group by in GQL` did not fix the aggregation.** The 2026-08-05 entry saying it did
  was a misread of an unchanged ten-item answer against a ten-item baseline. Compare re-run
  output side by side with the previous run, never from memory of what it "looked like."
- **Don't reintroduce cause B** (measures postdated generation). Tested and eliminated 2026-08-06.
- Measures being absent is **by design** and documented — not a consequence of the hidden
  measures table.

### The demo, separately

Demo runbook Ch.6 question #4 — *"which factories produce for our highest-intensity
suppliers?"* — is a dud on camera. The synthetic data is fully crossed: every supplier uses
38–40 of the 40 factories, so the honest answer is "all of them." The supplier↔factory links
need reshaping before that chapter is recorded. Post-meeting work.
