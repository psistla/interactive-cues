# Slides 1 and 4 — Microsoft Fabric IQ / Ontology, Thu 2026-08-06 PM

> ⚠️ **Superseded 2026-08-05.** The deck was rebuilt as six slides — Built · Shines · Fails ·
> Competitive · Ask · Sources — in `msft-deck.html` and `msft-deck.pptx`. This file is kept
> because its talk track, the read-the-room note and the do-not-claim list fed the speaker
> notes, and they are easier to edit here than in the build script.

**Content for the open and the close. Slides 2–3 are in `msft-competitive-position.md`.**

Every product claim below was observed in his own tenant on 2026-08-05 or cited to a live
Learn page with its last-updated date. Evidence and verdicts: `msft-spike-findings.md`.

**Time budget, 25 minutes:** slide 1 ≈ 6, slides 2–3 ≈ 8, slide 4 ≈ 4, leaves ≈ 7 for them.
The 7 minutes is the point of the meeting. Do not spend it on slides.

---

## Slide 1 · I built it, and it didn't behave the way your docs say

**Bottom line: the generator is the best thing in the product, two documented limitations
didn't reproduce, and the business definitions don't make it into the ontology.**

### What I built, 2026-08-05

Own tenant, footwear sustainability data. Lakehouse with 7 managed delta tables → Direct Lake
semantic model, 6 relationships, measures → **ontology generated from the semantic model** →
data agent with the ontology as its sole source.

**The compliment, and say it first.** Generation from an existing semantic model is the
strongest asset in this product and it is underplayed in your own documentation. Every
competitor starts you at an empty canvas. It inherited the relationships, and the manual work
afterward was renames, keys, and relationship bindings — which your docs correctly tell me to
expect.

**Coverage: 3 of the 8 tests I planned. Say the number out loud.** What follows is what
reproduced, not everything I intended to try.

### Three findings

**1 · Two documented limitations don't reproduce.**

| Documented | Observed |
|---|---|
| *"Ontology only supports managed lakehouse tables… not external tables that show in the lakehouse but reside in a different location."* Expected symptom: *"Entity type details shows no data."* | Internal OneLake shortcut appeared in the picker, bound, saved, **returned rows.** |
| *"You can't use lakehouses with OneLake security enabled as data sources for bindings."* Stated in prerequisites, limitations, **and** troubleshooting. Expected symptom: the lakehouse doesn't appear in the picker at all. | Lakehouse appeared, bound, served instances, **rendered charts.** |

Three pages say the second one shouldn't be possible. Either the docs are stale or something
shipped without them.

**2 · Measures don't reach the ontology, and the natural-language layer substitutes silently.**

Asked: *"Which factories produce for our highest-intensity suppliers?"* The agent ranked
factories by `grid_kg_co2e_per_kwh` — a raw Factory column — and described that column as
belonging to Supplier. Verified against the source CSVs.

The cause is in your own support matrix. Direct Lake: *"Querying data using bindings:
**Supported (without measures and calculated columns)**."* My `Carbon Intensity` measure was
never in the ontology. **The agent didn't pick a raw column over my definition — my definition
was gone, and nothing said so.**

**And I applied your documented workaround.** `Support group by in GQL`, from the
troubleshooting page's known-issue note on aggregation. **The answer didn't change.** Then I
generated a fresh ontology with the measures already in the model and asked again. **Same
answer.** Three runs, one result.

> The ontology is sold as a shared, machine-understandable vocabulary of the business. The
> business definitions — the measures, where the meaning actually lives — stay behind in the
> semantic model, and the agent answers anyway using whatever raw column has a similar name.

**3 · Generation is one-time.** The documented fix for any structural change is *regenerate* —
which discards the renames, keys, and relationship bindings your docs tell me to do by hand
afterward. And the FAQ confirms *"versioning isn't currently available."* The layer that
defines my business has no lifecycle.

### The two questions I'd most like answered

> **"I bound an ontology to a OneLake-security-enabled lakehouse and got rows. Your docs say
> that lakehouse shouldn't even appear in the picker. I was workspace admin, so I couldn't
> tell whether the row and column restrictions were enforced or read straight through.
> Which is it?"**

> **"Measures don't come across, so my definition of Carbon Intensity wasn't in the ontology.
> The agent answered anyway with a similar-sounding raw column and attributed it to the wrong
> entity type. How should an ontology signal that a business definition is missing rather than
> substituting for it?"**

---

### Talk track for slide 1

Open with the inversion. It is disarming, it is true, and it buys everything after it:

> *"I planned this conversation out of your documentation. Then I built it, and the product
> proved me wrong twice — in your favour. So I rewrote it."*

Then the compliment, then the coverage number, then the three findings. Do not editorialise on
finding 1; state what the docs say and what happened, and let them react. **The reaction to
finding 1 tells you the room** — if they already know, you're with the product group; if
they're surprised, you're with field or GTM and the meeting is a different one.

**On the missing measure, if pressed on why:** the documented Direct Lake exclusion is the
cause, and as of 2026-08-06 it is isolated rather than assumed. The lifecycle alternative —
measures postdating generation with no re-sync — was tested and eliminated by regenerating with
the measures in place. **Do not offer that caveat any more.** One mechanism, confirmed by
experiment.

**Do not claim as findings** — all documented, all checked:
import-mode binding failure · "non-time-series" vocabulary · hidden tables being excluded ·
measures being absent as a *bug* rather than by design.

---

## Slide 4 · What I'm asking for

**I've verified your product against your own documentation in my own tenant and found drift
in both directions. I'd like to keep doing that where it's useful to you, and to be positioned
to implement this at enterprise scope when it's ready.**

Four asks, laddered. Each one earns the next; only the first needs an answer today.

| | Ask | What it is | When |
|---|---|---|---|
| **1** | **Preview / design-partner access** | Early access and a channel to report what I find. I've already produced two contradictions and a design question in one evening, unaided. | **In the room. This is the ask.** |
| **2** | **Roadmap under NDA** | Enough forward visibility to advise clients honestly about sequencing — particularly OneLake security parity, measure support, and versioning. | Rides along with 1. |
| **3** | **Co-sell** | Joint pursuit where an enterprise account needs both the platform and the implementation. | NDA follow-up, not today. |
| **4** | **Implementation-partner positioning** | — | **Not requested.** Proved by 1–3. |

**The fourth is deliberately not on the table.** Asking to be an implementation partner is a
claim. Delivering useful field evidence under a design-partner arrangement is a demonstration.
If 1 through 3 go well, 4 doesn't need asking.

### What you get from me

- **In-tenant verification, not doc review.** Everything on slide 1 came from building it.
  This is the one asset in this conversation you cannot produce internally: an outside
  practitioner hitting the product cold with no support ticket and no PG in the loop.
- **Enterprise implementation experience** in Fabric, governance, and the agent-readiness work
  that has to happen before an ontology is worth anything.
- **Honest coverage.** I ran 3 of 8 planned tests and I told you so. When I say something
  reproduced, it reproduced.

### The close

> **"Your differentiation against Palantir and Databricks is governance. My strongest finding
> is that I couldn't tell whether governance is enforced through the ontology or read straight
> through — and I'd like to be in a position to find out properly."**

Then stop talking.

---

## Scope note

Nothing in this deck names the client, the account, or any competing platform in their
evaluation. The competitive material on slides 2–3 is market analysis from vendor
documentation only.

---

## One structural note on the deck itself

If the room turns out to be product group, **lead with the artifact, not slide 1.** The
strongest thing available is a live screen-share of a OneLake-security-enabled lakehouse bound
and serving rows next to the three doc pages saying it shouldn't appear in the picker. A PG
will engage with that in a way they won't engage with a bullet about it. Slides work as the
leave-behind and as the structure if the room is field or GTM — and since the composition is
unknown, having both is the right hedge. Have the tenant open either way.
