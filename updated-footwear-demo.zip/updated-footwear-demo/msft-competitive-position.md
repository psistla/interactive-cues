# Where Fabric Ontology wins, where it's behind

**Content for slides 2 and 3. Every product claim below is from vendor documentation, cited.**

---

## The one axis that organises the landscape

Everyone shipped "context for agents" in 2026. They are not the same product, and the
difference is **what layer of meaning each one actually declares.**

| | Declares | Relationships | Closes the loop? |
|---|---|---|---|
| **Snowflake** semantic views | Facts, dimensions, metrics | Join paths — `orders(customer_id) REFERENCES customers` | No |
| **Databricks** UC metric views | Governed metrics + agent metadata | Not first-class | No |
| **Fabric** Ontology | Entity types, properties, typed relationships, constraints | Named and typed — *suppliedBy* | No |
| **Palantir** Foundry | Object types, link types, **action types** | Named and typed, with cardinality | **Yes** |

Read down the "Relationships" column and the argument makes itself. Snowflake tells an
agent *how to join*. Databricks tells it *what a metric means*. Fabric and Palantir tell
it *what things are and how they relate*. Only two of the four are ontologies in any
serious sense, and Microsoft is one of them.

Then read the last column, and that is the gap.

**The line for the room:** *"Snowflake declares the join. Databricks declares the metric.
You declare the meaning — and Palantir declares the meaning and then acts on it."*

---

## What genuinely sets Fabric Ontology ahead

**1. It bootstraps from a semantic model. Nobody else does.**
Generate an ontology from an existing Power BI semantic model, inheriting the
relationships. Every other vendor starts you at an empty canvas. Against an install base
of hundreds of thousands of existing semantic models, this is the strongest asset in the
product and it is underplayed in the current documentation. **Say this first.** It is the
compliment that earns the criticism later.

**2. Relationships are named, typed, and constrained.**
*OrderLine suppliedBy Supplier* carries meaning; `dim_supplier_id REFERENCES id` carries
a join path. Snowflake's RELATIONSHIPS clause is explicitly the second thing — it exists
so Cortex Analyst stops inferring joins. That is a real problem solved, and it is a
smaller problem than the one Fabric is solving.

**3. Agent-first by construction.**
NL2Ontology, plus automatic routing to the right engine — GQL for Graph, KQL for
Eventhouse. Neither rival routes across storage engines from a business-term query.

**4. Multi-source time series binding.**
The static binding limit is the headline complaint, but entity types *do* accept bindings
from multiple time series sources across eventhouse and lakehouse. One entity carrying
both its analytical and real-time face is unusual and nobody is talking about it.

**5. No new platform.**
Palantir is a parallel estate with its own gravity. Fabric Ontology is an item in a
workspace you already own.

---

## What leaves it behind

**1. It answers. It cannot act. This is the strategic one.**
Foundry's ontology has **action types** as a first-class concept — the ontology is the
write path as well as the read path, so a decision becomes a transaction. Fabric Ontology
binds OneLake data for reading and grounding, and stops at the answer.

For a retail client, that is the difference between *"which factories produce for our
highest-risk suppliers"* and *"…and reroute this quarter's allocation away from them."*
Every executive asks the second question about ninety seconds after the first one.

This is the gap worth raising most carefully, because it is the one that isn't a bug list
— it's a product strategy question, and asking it well is what makes you interesting to a
PM rather than tedious.

**2. The binding layer is the whole weakness, and it's narrow.**
One static source per entity type. Managed tables only, no shortcuts. No OneLake security.
No column-mapping delta tables. Every blocking limit sits in binding, not modelling —
which is also the good news, and the basis of *model now, bind narrow*.

**3. No versioning.** Palantir versions the ontology; Databricks governs metric views
through Unity Catalog with ownership and lifecycle. Fabric has none of it on the layer
that defines Revenue.

**4. Manual refresh.** Both rivals' semantic objects resolve at query time against live
tables. Fabric's ontology graph answers from the last refresh, and nothing warns the user.

---

## The three sentences that carry the meeting

> **"You're the only one who can generate an ontology from a semantic model. That's the
> best thing in the product and it's buried in the docs."**

> **"Your differentiation against Palantir and Databricks is governance — and the ontology
> can't read OneLake-secured storage."**

> **"Palantir's ontology can act. Yours can only answer. Is that a sequencing decision or
> a scope decision?"**

The third is a question, deliberately. It is the highest-value thing you can ask, and the
answer tells you more about the roadmap than any slide they would show you.

---

## Scope note

Three comparators, not four. Palantir, Databricks and Snowflake are the ones live in
enterprise evaluations and the ones I could verify against vendor documentation today.
The graph-native independents (Timbr, RelationalAI, Stardog) would round out the picture,
but I have not verified their current state and an unverified fourth column in front of
Microsoft costs more than the completeness is worth.

Nothing on this page references the client, the account, or its evaluation.

---

## Sources

- [Unity Catalog semantics](https://docs.databricks.com/aws/en/uc-semantics/) · [Metric views](https://learn.microsoft.com/en-us/azure/databricks/uc-semantics/metric-views/)
- [Snowflake Cortex Analyst](https://docs.snowflake.com/en/user-guide/snowflake-cortex/cortex-analyst) · [Native semantic views](https://www.snowflake.com/en/blog/engineering/native-semantic-views-ai-bi/)
- [Palantir Ontology overview](https://www.palantir.com/docs/foundry/ontology/overview) · [Object types](https://www.palantir.com/docs/foundry/object-link-types/object-types-overview) · [Link types](https://www.palantir.com/docs/foundry/object-link-types/link-types-overview) · [Action types](https://www.palantir.com/docs/foundry/action-types/overview)
- [Fabric Ontology overview](https://learn.microsoft.com/en-us/fabric/iq/ontology/overview) · [Data binding](https://learn.microsoft.com/en-us/fabric/iq/ontology/how-to-bind-data) · [FAQ](https://learn.microsoft.com/en-us/fabric/iq/ontology/resources-frequently-asked-questions)
