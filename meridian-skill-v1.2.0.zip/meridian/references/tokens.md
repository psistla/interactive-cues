# Meridian Design System — Token Reference

This is the complete CSS custom properties file. Use these exact values when building any visual output.

```css
/* ═══════════════════════════════════════════════════════════════
   MERIDIAN DESIGN SYSTEM — CSS Custom Properties
   v1.2.0 · All contrast ratios computed with WCAG 2.1 relative luminance.

   CHANGELOG v1.2.0:
   - Fixed: contrast ratio comments (success-text 9.11, error-text 8.31,
     info-text 8.72) — previously rounded incorrectly
   - Added: dark mode semantic color overrides (success, warning, error, info)
     — v1.1 had no dark overrides → failed AA on neutral-950
   - Added: dark mode semantic bg tints as rgba() overlays
   - Added: --m-weight-extrabold (800) for hero headings / metric values
   - Added: line-height tokens (--m-leading-*)
   - Added: letter-spacing tokens (--m-tracking-*)
   - Added: --m-shadow-xl to match CSS token already present
   - Fixed: Manrope import trimmed to 400–700 (800 removed — use extrabold
     token only if you re-add the import weight)
   - Fixed: easing tokens wired into transition tokens
   - Added: scoped reset warning comment
   - Removed: border-radius: inherit from :focus-visible (no-op)
   - Added: --m-sidebar-docs (220px) for documentation context

   CHANGELOG v1.1.0:
   - Accent palette: teal → warm amber
   - Secondary text: neutral-500 → neutral-600 (WCAG AA fix, 8.18:1)
   - Tertiary text: → neutral-500 (AA-large only, 3.32:1)
   - Warning semantic: #D97706 → #EA580C (deconflict from amber accent)
   - Success semantic: #16A34A → #15803D (WCAG AA fix, 5.02:1)
   - Added semantic -text tokens for alert/badge title text
   - Fixed: --m-space-0.5 → --m-space-half (invalid CSS property)
   - Added: --m-space-7 (28px), z-index scale, dark mode hybrid
   - Added: skeleton, toast, modal, tooltip, icon, kbd tokens

   Usage:
     @import url('meridian-tokens.css');
     — OR —
     Paste this entire block into a <style> tag in any HTML/React artifact.

   Fonts (add to <head> or import in JS):
     https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700&display=swap
     https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600&display=swap
     https://fonts.googleapis.com/css2?family=Newsreader:ital,opsz,wght@0,6..72,400;0,6..72,500;1,6..72,400&display=swap

   Note: if using --m-weight-extrabold (800), add weight 800 back into the
   Manrope import above — it was trimmed from the default import in v1.2.0.
   ═══════════════════════════════════════════════════════════════ */

:root {
  /* ─── FONTS ───────────────────────────────────────────────── */
  --m-font-primary: 'Manrope', system-ui, -apple-system, sans-serif;
  --m-font-code: 'JetBrains Mono', 'Fira Code', 'Consolas', monospace;
  --m-font-serif: 'Newsreader', Georgia, serif;

  /* ─── TYPE SCALE ──────────────────────────────────────────── */
  --m-text-xs:   0.6875rem;  /* 11px */
  --m-text-sm:   0.8125rem;  /* 13px */
  --m-text-base: 0.9375rem;  /* 15px */
  --m-text-lg:   1.0625rem;  /* 17px */
  --m-text-xl:   1.25rem;    /* 20px */
  --m-text-2xl:  1.5rem;     /* 24px */
  --m-text-3xl:  1.875rem;   /* 30px */
  --m-text-4xl:  2.25rem;    /* 36px */
  --m-text-5xl:  3rem;       /* 48px */

  /* ─── FONT WEIGHTS ────────────────────────────────────────── */
  --m-weight-regular:   400;
  --m-weight-medium:    500;
  --m-weight-semibold:  600;
  --m-weight-bold:      700;
  --m-weight-extrabold: 800;  /* hero headings, metric values only */

  /* ─── LINE HEIGHTS ────────────────────────────────────────── */
  --m-leading-tight:    1.25;  /* headings, compact UI */
  --m-leading-snug:     1.4;   /* subheadings, labels */
  --m-leading-normal:   1.6;   /* body text default */
  --m-leading-relaxed:  1.7;   /* documentation / long-form reading */

  /* ─── LETTER SPACING ──────────────────────────────────────── */
  --m-tracking-tight:    -0.015em;  /* xl–2xl headings */
  --m-tracking-tighter:  -0.025em;  /* 3xl–4xl headings */
  --m-tracking-tightest: -0.035em;  /* 5xl hero headings */
  --m-tracking-wide:      0.04em;   /* labels, overlines, table headers */

  /* ─── NEUTRAL PALETTE ─────────────────────────────────────── */
  --m-neutral-0:   #FFFFFF;
  --m-neutral-50:  #F8F9FA;
  --m-neutral-100: #F1F3F5;
  --m-neutral-200: #E9ECEF;
  --m-neutral-300: #DEE2E6;
  --m-neutral-400: #ADB5BD;
  --m-neutral-500: #868E96;  /* AA-large only (3.32:1 on white). Placeholders, captions ≥14px */
  --m-neutral-600: #495057;  /* AA normal (8.18:1 on white). Default secondary text */
  --m-neutral-700: #343A40;
  --m-neutral-800: #212529;  /* Primary text (15.43:1 on white) */
  --m-neutral-900: #16191D;
  --m-neutral-950: #0D0F12;  /* Dark mode base background */

  /* ─── PRIMARY PALETTE (Deep Indigo) ───────────────────────── */
  --m-primary-50:  #EEF2FF;
  --m-primary-100: #E0E7FF;
  --m-primary-200: #C7D2FE;
  --m-primary-300: #A5B4FC;  /* Dark mode hover */
  --m-primary-400: #818CF8;  /* Dark mode primary */
  --m-primary-500: #6366F1;
  --m-primary-600: #4F46E5;  /* Default primary (6.29:1 on white) */
  --m-primary-700: #4338CA;
  --m-primary-800: #3730A3;
  --m-primary-900: #312E81;

  /* ─── ACCENT PALETTE (Warm Amber) ─────────────────────────── */
  --m-accent-50:  #FFFBEB;
  --m-accent-100: #FEF3C7;
  --m-accent-200: #FDE68A;
  --m-accent-300: #FCD34D;  /* Dark mode accent-vivid */
  --m-accent-400: #FBBF24;  /* Dark mode accent */
  --m-accent-500: #F59E0B;
  --m-accent-600: #D97706;
  --m-accent-700: #B45309;  /* Text-safe accent on white (5.02:1 ✓ AA) */
  --m-accent-800: #92400E;
  --m-accent-900: #78350F;

  /* ─── SEMANTIC COLORS ─────────────────────────────────────── 
     Pattern: base color for icons/borders/badges.
     -text variant for alert titles and badge text (guaranteed AA).
     Alert body text uses neutral-800. */
  --m-success:      #15803D;  /* green-700: 5.02:1 on white ✓ AA */
  --m-success-bg:   #F0FDF4;
  --m-success-text: #14532D;  /* green-900: 9.11:1 on white */
  --m-warning:      #EA580C;  /* orange-600: 3.56:1 on white (AA-large; pair with text) */
  --m-warning-bg:   #FFF7ED;
  --m-warning-text: #9A3412;  /* orange-800: 7.31:1 on white ✓ AA */
  --m-error:        #DC2626;  /* red-600: 4.83:1 on white ✓ AA */
  --m-error-bg:     #FEF2F2;
  --m-error-text:   #991B1B;  /* red-800: 8.31:1 on white ✓ AA */
  --m-info:         #2563EB;  /* blue-600: 5.17:1 on white ✓ AA */
  --m-info-bg:      #EFF6FF;
  --m-info-text:    #1E40AF;  /* blue-800: 8.72:1 on white ✓ AA */

  /* ─── SEMANTIC ALIASES ────────────────────────────────────── */
  --m-bg:             var(--m-neutral-0);
  --m-surface:        var(--m-neutral-50);
  --m-border:         var(--m-neutral-200);
  --m-border-subtle:  var(--m-neutral-100);
  --m-text:           var(--m-neutral-800);
  --m-text-secondary: var(--m-neutral-600);
  --m-text-tertiary:  var(--m-neutral-500);
  --m-primary:        var(--m-primary-600);
  --m-primary-hover:  var(--m-primary-700);
  --m-primary-subtle: var(--m-primary-50);
  --m-accent:         var(--m-accent-700);        /* text-safe default */
  --m-accent-vivid:   var(--m-accent-500);        /* decorative only, not for text on white */
  --m-accent-subtle:  var(--m-accent-50);

  /* ─── SPACING SCALE (4px base) ────────────────────────────── */
  --m-space-0:    0;
  --m-space-half: 0.125rem;   /* 2px  — tight inline spacing */
  --m-space-1:    0.25rem;    /* 4px  — icon-to-label gap */
  --m-space-2:    0.5rem;     /* 8px  — intra-component padding */
  --m-space-3:    0.75rem;    /* 12px — compact component padding */
  --m-space-4:    1rem;       /* 16px — standard component padding */
  --m-space-5:    1.25rem;    /* 20px — related group gap */
  --m-space-6:    1.5rem;     /* 24px — card padding, section gap */
  --m-space-7:    1.75rem;    /* 28px — intermediate spacing */
  --m-space-8:    2rem;       /* 32px — section spacing */
  --m-space-10:   2.5rem;     /* 40px — major section gap */
  --m-space-12:   3rem;       /* 48px — page section separation */
  --m-space-16:   4rem;       /* 64px — hero spacing */
  --m-space-20:   5rem;       /* 80px — page top/bottom padding */
  --m-space-24:   6rem;       /* 96px — landing page sections */
  --m-space-32:   8rem;       /* 128px — maximum breathing room */

  /* ─── BORDER RADIUS ───────────────────────────────────────── */
  --m-radius-none: 0;
  --m-radius-sm:   4px;
  --m-radius-md:   8px;       /* buttons, inputs, code blocks */
  --m-radius-lg:   12px;      /* cards, panels */
  --m-radius-xl:   16px;      /* modals, large panels */
  --m-radius-full: 9999px;    /* pills, badges, avatars */

  /* ─── SHADOWS ─────────────────────────────────────────────── */
  --m-shadow-sm: 0 1px 2px rgba(0,0,0,0.04);
  --m-shadow-md: 0 2px 8px rgba(0,0,0,0.06);
  --m-shadow-lg: 0 4px 16px rgba(0,0,0,0.08);
  --m-shadow-xl: 0 8px 32px rgba(0,0,0,0.1);

  /* ─── EASING ──────────────────────────────────────────────── */
  --m-ease-out-expo: cubic-bezier(0.16, 1, 0.3, 1);
  --m-ease-in-expo:  cubic-bezier(0.7, 0, 0.84, 0);
  --m-ease-in-out:   cubic-bezier(0.45, 0, 0.55, 1);

  /* ─── TRANSITIONS ─────────────────────────────────────────── */
  --m-transition-fast:  120ms ease;                         /* hover, toggles */
  --m-transition-base:  200ms ease;                         /* standard transitions */
  --m-transition-slow:  300ms ease;                         /* panels, drawers */
  --m-transition-enter: 250ms var(--m-ease-out-expo);       /* elements entering */
  --m-transition-exit:  150ms var(--m-ease-in-expo);        /* elements exiting */

  /* ─── Z-INDEX SCALE ───────────────────────────────────────── */
  --m-z-base:     0;
  --m-z-raised:   10;
  --m-z-dropdown: 100;
  --m-z-sticky:   200;
  --m-z-overlay:  300;
  --m-z-modal:    400;
  --m-z-toast:    500;
  --m-z-tooltip:  600;

  /* ─── LAYOUT ──────────────────────────────────────────────── */
  --m-max-content:  1280px;
  --m-max-prose:    680px;
  --m-sidebar:      240px;
  --m-sidebar-sm:   64px;
  --m-sidebar-docs: 220px;   /* documentation left-nav TOC width */

  /* ─── COMPONENT TOKENS ────────────────────────────────────── */
  --m-skeleton-base:     var(--m-neutral-200);
  --m-skeleton-shine:    var(--m-neutral-100);
  --m-skeleton-duration: 1.8s;

  --m-tooltip-bg:      var(--m-neutral-900);
  --m-tooltip-text:    var(--m-neutral-0);
  --m-tooltip-radius:  var(--m-radius-md);
  --m-tooltip-delay:   300ms;
  --m-tooltip-max-w:   240px;

  --m-modal-overlay:   rgba(0, 0, 0, 0.5);
  --m-modal-max-w:     560px;
  --m-modal-max-w-lg:  720px;
  --m-modal-radius:    var(--m-radius-xl);
  --m-modal-padding:   var(--m-space-8);

  --m-toast-max-w:     420px;
  --m-toast-radius:    var(--m-radius-lg);
  --m-toast-duration:  5000ms;

  --m-icon-sm:    16px;
  --m-icon-md:    20px;
  --m-icon-lg:    24px;
  --m-icon-touch: 44px;    /* minimum touch/click target */
}

/* ─── BASE RESET ──────────────────────────────────────────────
   ⚠ ARTIFACT-ONLY: This aggressive reset strips all margin/padding.
   Remove or scope this block when importing into existing projects
   that have their own reset or normalize layer.
   ──────────────────────────────────────────────────────────── */
*, *::before, *::after {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

/* ─── FOCUS RING (ACCESSIBILITY) ──────────────────────────── */
:focus-visible {
  outline: 2px solid var(--m-primary);
  outline-offset: 2px;
}

/* ─── REDUCED MOTION ──────────────────────────────────────── */
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: 0.01ms !important;
    transition-duration: 0.01ms !important;
  }
}

/* ─── SELECTION ───────────────────────────────────────────── */
::selection {
  background: var(--m-primary-100);
  color: var(--m-primary-900);
}

/* ─── SKELETON SHIMMER ────────────────────────────────────── */
@keyframes m-shimmer {
  0%   { background-position: -200% 0; }
  100% { background-position: 200% 0; }
}

.m-skeleton {
  background: linear-gradient(90deg,
    var(--m-skeleton-base) 25%,
    var(--m-skeleton-shine) 50%,
    var(--m-skeleton-base) 75%
  );
  background-size: 200% 100%;
  animation: m-shimmer var(--m-skeleton-duration) ease-in-out infinite;
  border-radius: var(--m-radius-sm);
}

/* ─── DARK MODE ───────────────────────────────────────────── 
   Three activation methods (same tokens, different triggers):
   
   1. .m-dark    → Scoped to a container (code panels, chart areas,
                    slide sections). Use in artifacts, docs, decks.
   
   2. .dark      → Global toggle on <html> or <body>. Use in web apps
                    with a light/dark toggle.
   
   3. @media     → OS-level preference (opt-in, uncomment below).
                    Not active by default — projects opt in.
   
   All three resolve the same token overrides. A project picks
   whichever activation method fits its architecture. */
.m-dark,
.dark {
  /* ─ Layout tokens ─ */
  --m-bg:             var(--m-neutral-950);
  --m-surface:        var(--m-neutral-900);
  --m-border:         var(--m-neutral-700);
  --m-border-subtle:  var(--m-neutral-800);
  --m-text:           var(--m-neutral-200);
  --m-text-secondary: var(--m-neutral-400);
  --m-text-tertiary:  var(--m-neutral-500);
  --m-primary:        var(--m-primary-400);
  --m-primary-hover:  var(--m-primary-300);
  --m-primary-subtle: var(--m-primary-900);
  --m-accent:         var(--m-accent-400);
  --m-accent-vivid:   var(--m-accent-300);
  --m-accent-subtle:  var(--m-accent-900);

  /* ─ Semantic colors (dark) ─
     Lighter tints that pass AA on neutral-950 (#0D0F12).
     bg tints use rgba overlays instead of light pastels. */
  --m-success:      #4ADE80;  /* green-400: 9.74:1 on #0D0F12 ✓ AA */
  --m-success-bg:   rgba(74, 222, 128, 0.10);
  --m-success-text: #86EFAC;  /* green-300: 13.14:1 on #0D0F12 */
  --m-warning:      #FB923C;  /* orange-400: 8.13:1 on #0D0F12 ✓ AA */
  --m-warning-bg:   rgba(251, 146, 60, 0.10);
  --m-warning-text: #FDBA74;  /* orange-300: 11.09:1 on #0D0F12 */
  --m-error:        #F87171;  /* red-400: 6.59:1 on #0D0F12 ✓ AA */
  --m-error-bg:     rgba(248, 113, 113, 0.10);
  --m-error-text:   #FCA5A5;  /* red-300: 9.58:1 on #0D0F12 */
  --m-info:         #60A5FA;  /* blue-400: 6.90:1 on #0D0F12 ✓ AA */
  --m-info-bg:      rgba(96, 165, 250, 0.10);
  --m-info-text:    #93C5FD;  /* blue-300: 9.62:1 on #0D0F12 */

  /* ─ Shadows (higher opacity for dark surfaces) ─ */
  --m-shadow-sm: 0 1px 2px rgba(0,0,0,0.2);
  --m-shadow-md: 0 2px 8px rgba(0,0,0,0.3);
  --m-shadow-lg: 0 4px 16px rgba(0,0,0,0.4);
  --m-shadow-xl: 0 8px 32px rgba(0,0,0,0.5);

  /* ─ Component tokens (dark) ─ */
  --m-skeleton-base:  var(--m-neutral-800);
  --m-skeleton-shine: var(--m-neutral-700);
  --m-tooltip-bg:     var(--m-neutral-200);
  --m-tooltip-text:   var(--m-neutral-900);

  color-scheme: dark;
}

.m-dark ::selection,
.dark ::selection {
  background: var(--m-primary-800);
  color: var(--m-primary-100);
}

/* ─── OS-LEVEL DARK PREFERENCE (opt-in) ───────────────────── 
   Uncomment this block if your project should respect the user's
   OS dark mode setting automatically (no manual toggle needed).
   
   @media (prefers-color-scheme: dark) {
     :root {
       --m-bg:             var(--m-neutral-950);
       --m-surface:        var(--m-neutral-900);
       --m-border:         var(--m-neutral-700);
       --m-border-subtle:  var(--m-neutral-800);
       --m-text:           var(--m-neutral-200);
       --m-text-secondary: var(--m-neutral-400);
       --m-text-tertiary:  var(--m-neutral-500);
       --m-primary:        var(--m-primary-400);
       --m-primary-hover:  var(--m-primary-300);
       --m-primary-subtle: var(--m-primary-900);
       --m-accent:         var(--m-accent-400);
       --m-accent-vivid:   var(--m-accent-300);
       --m-accent-subtle:  var(--m-accent-900);
       --m-success:        #4ADE80;
       --m-success-bg:     rgba(74, 222, 128, 0.10);
       --m-success-text:   #86EFAC;
       --m-warning:        #FB923C;
       --m-warning-bg:     rgba(251, 146, 60, 0.10);
       --m-warning-text:   #FDBA74;
       --m-error:          #F87171;
       --m-error-bg:       rgba(248, 113, 113, 0.10);
       --m-error-text:     #FCA5A5;
       --m-info:           #60A5FA;
       --m-info-bg:        rgba(96, 165, 250, 0.10);
       --m-info-text:      #93C5FD;
       --m-shadow-sm: 0 1px 2px rgba(0,0,0,0.2);
       --m-shadow-md: 0 2px 8px rgba(0,0,0,0.3);
       --m-shadow-lg: 0 4px 16px rgba(0,0,0,0.4);
       --m-shadow-xl: 0 8px 32px rgba(0,0,0,0.5);
       --m-skeleton-base:  var(--m-neutral-800);
       --m-skeleton-shine: var(--m-neutral-700);
       --m-tooltip-bg:     var(--m-neutral-200);
       --m-tooltip-text:   var(--m-neutral-900);
       color-scheme: dark;
     }
     ::selection {
       background: var(--m-primary-800);
       color: var(--m-primary-100);
     }
   }
*/

/* ─── KBD / KEYBOARD SHORTCUT ─────────────────────────────── */
.m-kbd {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 22px;
  height: 22px;
  padding: 0 6px;
  font-family: var(--m-font-code);
  font-size: var(--m-text-xs);
  font-weight: var(--m-weight-medium);
  color: var(--m-text-secondary);
  background: var(--m-surface);
  border: 1px solid var(--m-border);
  border-bottom-width: 2px;
  border-radius: var(--m-radius-sm);
  line-height: 1;
}
```
