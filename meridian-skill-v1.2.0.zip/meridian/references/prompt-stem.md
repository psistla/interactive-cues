# Meridian Design System — Claude Prompt Stem
# ─────────────────────────────────────────────
# v1.2.0 · All contrast ratios computed with WCAG 2.1 relative luminance formula.
#
# USAGE MODES:
#   Full block    → paste entire thing for new projects/artifacts
#   Quick ref     → paste just the "MERIDIAN QUICK REF" section for iterations
#   Per-context   → paste the relevant CONTEXT OVERRIDE section

# ═══════════════════════════════════════════════════════════════
# FULL MERIDIAN INSTRUCTION BLOCK
# ═══════════════════════════════════════════════════════════════

"""
DESIGN SYSTEM: Apply the Meridian design system to all UI output.

FONTS:
- Primary: Manrope (weights 400/500/600/700)
- Code: JetBrains Mono (weights 400/500/600)
- Serif (editorial only): Newsreader
- Import: https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap

TYPE SCALE: xs=11px, sm=13px, base=15px, lg=17px, xl=20px, 2xl=24px, 3xl=30px, 4xl=36px, 5xl=48px
- Headings: negative letter-spacing (-0.015em to -0.035em), weight 600-700
  - Tracking tokens: tight=-0.015em (xl–2xl), tighter=-0.025em (3xl–4xl), tightest=-0.035em (5xl)
- Body: 15px/1.6, neutral-800 (#212529)
- Secondary text: neutral-600 (#495057) — NOT neutral-500
- Tertiary/placeholder: neutral-500 (#868E96) — large text (≥14px) or decorative only
- Labels/overlines: 11px, uppercase, 0.04em tracking, weight 600
- Line heights: tight=1.25 (headings), snug=1.4 (subheadings), normal=1.6 (body), relaxed=1.7 (docs)

COLORS:
- Neutrals: 0=#FFF, 50=#F8F9FA, 100=#F1F3F5, 200=#E9ECEF, 300=#DEE2E6, 400=#ADB5BD, 500=#868E96, 600=#495057, 700=#343A40, 800=#212529, 900=#16191D, 950=#0D0F12
- Primary (deep indigo): 50=#EEF2FF, 100=#E0E7FF, 200=#C7D2FE, 300=#A5B4FC, 400=#818CF8, 500=#6366F1, 600=#4F46E5, 700=#4338CA, 800=#3730A3, 900=#312E81
- Accent (warm amber): 50=#FFFBEB, 100=#FEF3C7, 200=#FDE68A, 300=#FCD34D, 400=#FBBF24, 500=#F59E0B, 600=#D97706, 700=#B45309, 800=#92400E, 900=#78350F
  - Accent text on white: use amber-700 (#B45309, 5.02:1) — never amber-500/600 for body text
  - Accent decorative (fills, borders, highlights): amber-500 (#F59E0B) or amber-400 (#FBBF24)
- Semantic: success=#15803D, warning=#EA580C, error=#DC2626, info=#2563EB
  - Alert title text: success-text=#14532D (9.11:1), warning-text=#9A3412 (7.31:1), error-text=#991B1B (8.31:1), info-text=#1E40AF (8.72:1)
  - Alert body text: always neutral-800
  - Semantic bg tints: success=#F0FDF4, warning=#FFF7ED, error=#FEF2F2, info=#EFF6FF
  - Note: warning base (#EA580C) is 3.56:1 on white — AA-large only. Always pair with text label, never use as sole indicator.
- Borders: neutral-200 default, neutral-100 subtle
- Backgrounds: neutral-0 base, neutral-50 surface

SPACING: 4px base unit. Scale: 2/4/8/12/16/20/24/28/32/40/48/64/80/96/128px.
- Card padding: 24px. Component internal: 8-12px. Section gaps: 32-48px.

COMPONENTS:
- Border radius: 8px buttons/inputs/code, 12px cards, 9999px pills/badges, 16px modals
- Shadows: sm=0 1px 2px rgba(0,0,0,0.04), md=0 2px 8px rgba(0,0,0,0.06), lg=0 4px 16px rgba(0,0,0,0.08), xl=0 8px 32px rgba(0,0,0,0.1)
- Buttons: 600 weight, 8px radius, padding 9px 20px (md). Min touch target 44x44px.
- Tables: 11px uppercase headers (weight 600, 0.04em tracking), 1px neutral-100 row borders, 10px 16px cell padding
- Code blocks: neutral-900 bg, neutral-100 text, 13px JetBrains Mono, 8px radius. Dark mode: neutral-950 bg, neutral-200 text, 1px neutral-700 border.
- Alerts: semantic-bg + 1px border at 13% opacity + icon (semantic color) + body text (neutral-800) + optional title (semantic-text token)
- Badges: 11px, 600 weight, uppercase, 0.04em tracking, pill shape (9999px), semantic-tinted bg, semantic-text color
- Tooltips: neutral-900 bg, white text, 8px radius, shadow-lg, 300ms delay, max-width 240px
- Modals: 50% black overlay, 560px max-width (720px large), 16px radius, 32px padding
- Toasts: bottom-right, 420px max-width, 12px radius, 5s auto-dismiss, stack max 3
- Skeletons: neutral-200 → neutral-100 shimmer, 1.8s cycle, match final layout shape
- Empty states: centered, 48px illustration (gray-toned), heading + description + CTA button
- Dropdowns: 8px radius, shadow-md, 44px item height (touch-safe), 1px separator, max 7 visible items
- Icons: Lucide library, 20px default (16px inline, 24px prominent), 1.5px stroke width

Z-INDEX SCALE: base=0, raised=10, dropdown=100, sticky=200, overlay=300, modal=400, toast=500, tooltip=600

MOTION: 120ms fast (hover), 200ms base (transitions), 300ms slow (panels), 250ms ease-out-expo (enter), 150ms ease-in-expo (exit). Always respect prefers-reduced-motion.
- Easing curves: ease-out-expo=cubic-bezier(0.16,1,0.3,1), ease-in-expo=cubic-bezier(0.7,0,0.84,0), ease-in-out=cubic-bezier(0.45,0,0.55,1)

DARK MODE:
- Three activation methods (same tokens, project picks one):
  1. .m-dark class on a container → scoped dark panels (artifacts, docs, slides)
  2. .dark class on <html> or <body> → global app toggle (web apps)
  3. @media prefers-color-scheme: dark → OS preference (opt-in, commented by default)
- Dark bg: neutral-950 (#0D0F12). Dark surface: neutral-900 (#16191D)
- Dark text: neutral-200 (#E9ECEF). Dark secondary: neutral-400 (#ADB5BD). Dark borders: neutral-700 (#343A40)
- Dark primary: primary-400 (#818CF8). Dark primary hover: primary-300 (#A5B4FC)
- Dark accent: accent-400 (#FBBF24). Dark accent-vivid: accent-300 (#FCD34D)
- Dark semantic overrides (all pass AA on neutral-950):
  - success: #4ADE80 (9.74:1), success-text: #86EFAC, success-bg: rgba(74,222,128,0.10)
  - warning: #FB923C (8.13:1), warning-text: #FDBA74, warning-bg: rgba(251,146,60,0.10)
  - error: #F87171 (6.59:1), error-text: #FCA5A5, error-bg: rgba(248,113,113,0.10)
  - info: #60A5FA (6.90:1), info-text: #93C5FD, info-bg: rgba(96,165,250,0.10)
- Dark code blocks: neutral-950 bg, neutral-200 text, 1px neutral-700 border
- Dark shadows use higher opacity (0.2-0.5)

LAYOUT: Sidebar 240px (64px collapsed) + fluid content. Max content 1280px. Max prose 680px. 12-column grid. Docs sidebar: 220px.

ACCESSIBILITY — NON-NEGOTIABLE:
- Focus ring: 2px solid primary-600, 2px offset
- Touch targets: ≥ 44x44px
- Color never sole indicator of state — always pair with icon + text
- Tertiary text (neutral-500) only for text ≥14px or purely decorative elements
- All interactive elements keyboard-navigable (Tab, Enter, Escape, Arrow keys)
- prefers-reduced-motion disables all animation

ANTI-PATTERNS — NEVER:
- Use Inter, Roboto, Arial, or system-ui as visible font choice
- Purple gradients on white backgrounds
- Rounded corners > 16px (except pills)
- Looping/decorative animations
- Color as sole state indicator
- Generic card layouts without clear hierarchy
- neutral-500 for body text under 14px (fails AA)
- amber-500/600 as text color on white (fails AA)
- Light-mode semantic bg tints (#F0FDF4 etc.) in dark mode (use rgba overlays)
"""

# ═══════════════════════════════════════════════════════════════
# MERIDIAN QUICK REF (for iterations on existing artifacts)
# ═══════════════════════════════════════════════════════════════

"""
Continue using Meridian design system. Key tokens:
- Font: Manrope / JetBrains Mono
- Primary: #4F46E5 (indigo-600), Accent: #B45309 text / #F59E0B decorative (amber)
- Text: #212529, Secondary: #495057, Tertiary: #868E96 (≥14px only), Border: #E9ECEF
- Radius: 8px standard, 12px cards, 9999px pills/badges, 16px modals. Spacing: 4px base grid.
- Shadows: sm/md/lg/xl. z-index: dropdown=100, modal=400, toast=500.
- Line heights: tight=1.25, snug=1.4, normal=1.6, relaxed=1.7
- Tracking: tight=-0.015em, tighter=-0.025em, tightest=-0.035em, wide=0.04em
- Dark mode: .m-dark (scoped panels) or .dark (global app toggle), bg=#0D0F12, text=#E9ECEF, primary=#818CF8, accent=#FBBF24
- Dark semantics: success=#4ADE80, warning=#FB923C, error=#F87171, info=#60A5FA (rgba bg tints, NOT light pastels)
- Icons: Lucide, 20px default, 1.5px stroke
"""

# ═══════════════════════════════════════════════════════════════
# CONTEXT OVERRIDES — append ONE of these to the full block
# ═══════════════════════════════════════════════════════════════

# --- FOR WEB APPS (dashboards, tools) ---
"""
CONTEXT: Web application.
- Full component system. Sidebar + content layout.
- Data-dense: tables, metric cards, filter bars, expandable rows.
- 15px base type. 32px section spacing. 24px card padding.
- Keyboard shortcuts for power users.
- Skeleton loading states for async data. Empty states for zero-data views.
- Toast notifications for async actions (bottom-right, 5s auto-dismiss).
"""

# --- FOR DOCUMENTATION (technical docs, READMEs) ---
"""
CONTEXT: Documentation / technical writing.
- Left nav TOC (220px, uses --m-sidebar-docs) + right-side page TOC.
- 17px body text, 1.7 line-height (--m-leading-relaxed) for extended reading.
- Max prose width: 680px.
- Code blocks with copy button + syntax highlighting.
- Anchor links on all headings.
- Kbd component for keyboard shortcuts: .m-kbd class.
"""

# --- FOR SLIDE DECKS (conference talks, client presentations) ---
"""
CONTEXT: Presentation slides.
- Scale all type 1.5x minimum. Code blocks 18px minimum, max 15 lines.
- Max 6 bullets per slide. One idea per slide.
- 48px minimum spacing between elements.
- Dark variant (.m-dark) for code-heavy slides.
- Simplified diagrams: max 7 visible nodes.
- Accent amber for emphasis/highlight callouts — high contrast on projection.
"""

# --- FOR GITHUB / OPEN SOURCE (READMEs, issue templates) ---
"""
CONTEXT: GitHub repository.
- README structure: badges → one-line desc → screenshot → install → usage → API → contributing
- Use shields.io badges with Meridian colors: ?color=4F46E5 (primary), ?color=B45309 (accent)
- Screenshots in both light and dark variants where applicable.
- ASCII-compatible diagrams in markdown.
- Issue/PR templates follow Meridian form patterns.
"""

# --- FOR DATA VISUALIZATIONS (charts, dashboards) ---
"""
CONTEXT: Data visualization.
- Chart color sequence: #4F46E5 (indigo), #B45309 (amber), #818CF8 (indigo-400), #FBBF24 (amber-400), #868E96 (neutral-500), #6366F1 (indigo-500), #D97706 (amber-600)
- Axis labels: 11px JetBrains Mono, neutral-600 (#495057) — NOT neutral-500 (11px fails AA at 3.32:1)
- Grid lines: neutral-100 (#F1F3F5), 1px. No heavy borders on chart areas.
- Tooltips: neutral-900 bg, white text, 8px radius, shadow-lg
- Metric cards: value 24px+ bold, label 12px neutral-600 above (not neutral-500)
- Never use 3D effects, drop shadows on bars, or gradient fills in charts.
- Wrap chart containers in .m-dark for dark-background data panels.
"""
