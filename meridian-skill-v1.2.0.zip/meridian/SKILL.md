---
name: meridian
description: Apply the Meridian design system to all visual outputs including React artifacts, HTML pages, dashboards, presentations, slide decks, data visualizations, charts, documentation, and any UI components. Trigger this skill whenever the user asks to build, create, design, or style any visual interface, frontend component, artifact, web page, slide deck, dashboard, chart, or data visualization. Also trigger when the user says "use Meridian", mentions their design system, or asks for something styled, branded, or visually polished. This is a private signature design system — do NOT mention it by name in outputs unless the user does first. Apply it silently as the default styling approach for all visual work.
---

# Meridian Design System

Meridian is the user's private signature design system for all visual outputs. Apply it to every artifact, component, page, dashboard, presentation, and visualization without being asked. It is not public — never mention the name "Meridian" in deliverables unless the user does first.

## When You Read This Skill

Before writing any visual code (React, HTML, CSS, SVG, charts), read this file first, then load `references/tokens.md` for exact hex values and token specifications.

## Design Philosophy

- **Minimal but not empty** — every element earns its place
- **Data-dense but cognitively calm** — strict hierarchy reduces load
- **Calm, confident visual language** — no decoration, no over-explanation
- **Accessibility is architecture** — WCAG AA+ is the baseline, not the target

## Typography

| Role | Font | Weights |
|------|------|---------|
| Primary (interface) | Manrope | 400, 500, 600, 700 |
| Code (monospace) | JetBrains Mono | 400, 500, 600 |
| Serif (editorial only) | Newsreader | 400, 500 |

**Google Fonts import:**
```
https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap
```

**Type scale:** xs=11px, sm=13px, base=15px, lg=17px, xl=20px, 2xl=24px, 3xl=30px, 4xl=36px, 5xl=48px

**Weights:** 400/500/600/700 standard; 800 (`--m-weight-extrabold`) for hero headings and metric values only — requires re-adding weight 800 to the Manrope import.

**Line heights:** tight=1.25 (headings), snug=1.4 (subheadings), normal=1.6 (body), relaxed=1.7 (docs/long-form)
**Letter spacing:** tight=-0.015em (xl–2xl), tighter=-0.025em (3xl–4xl), tightest=-0.035em (5xl), wide=0.04em (labels/overlines/table headers)

- Headings: negative letter-spacing (-0.015em to -0.035em), weight 600-700
- Body: 15px/1.6, neutral-800 (#212529)
- Secondary text: neutral-600 (#495057) — NOT neutral-500
- Tertiary/placeholder: neutral-500 (#868E96) — only for text ≥14px or decorative
- Labels/overlines: 11px, uppercase, 0.04em tracking, weight 600

## Color System

See `references/tokens.md` for the full palette. Key values:

**Primary (deep indigo):** #4F46E5 (600), #4338CA (700 hover)
**Accent (warm amber):** #B45309 (700, text-safe), #F59E0B (500, decorative only)
**Neutrals:** #212529 (800, body text), #495057 (600, secondary), #E9ECEF (200, borders)

**Semantic states:**
- Success: #15803D (icon/border, 5.02:1), #14532D (title text, 9.11:1), #F0FDF4 (bg)
- Warning: #EA580C (icon/border, 3.56:1 — AA-large only, pair with text), #9A3412 (title text, 7.31:1), #FFF7ED (bg)
- Error: #DC2626 (icon/border, 4.83:1), #991B1B (title text, 8.31:1), #FEF2F2 (bg)
- Info: #2563EB (icon/border, 5.17:1), #1E40AF (title text, 8.72:1), #EFF6FF (bg)

**Critical contrast rules:**
- NEVER use neutral-500 (#868E96) as text color for text < 14px (3.32:1 fails AA)
- NEVER use accent-500 (#F59E0B) or accent-600 (#D97706) as text on white (fails AA)
- Accent text on white must use accent-700 (#B45309, 5.02:1)
- Alert body text: always neutral-800, not the semantic color

**Chart color sequence:** #4F46E5, #B45309, #818CF8, #FBBF24, #868E96, #6366F1, #D97706

## Spacing

4px base unit. Scale: 2/4/8/12/16/20/24/28/32/40/48/64/80/96/128px.
- Card padding: 24px
- Component internal: 8-12px
- Section gaps: 32-48px

## Components

| Component | Radius | Key specs |
|-----------|--------|-----------|
| Buttons | 8px | 600 weight, padding 9px 20px (md), min touch 44px |
| Inputs | 8px | border neutral-300, focus: primary-600 |
| Cards | 12px | border neutral-200, padding 24px, shadow-sm |
| Modals | 16px | 50% overlay, 560px max-width, 32px padding |
| Badges | 9999px (pill) | 11px, 600 weight, uppercase, 0.04em tracking |
| Code blocks | 8px | neutral-950 bg, neutral-100 text, 13px JetBrains Mono |
| Tables | — | 11px uppercase headers, 1px neutral-100 row borders |
| Tooltips | 8px | neutral-900 bg, white text, 300ms delay, 240px max |
| Toasts | 12px | bottom-right, 420px max, 5s auto-dismiss |

**Shadows:** sm=0 1px 2px rgba(0,0,0,0.04), md=0 2px 8px rgba(0,0,0,0.06), lg=0 4px 16px rgba(0,0,0,0.08)

**Z-index:** base=0, raised=10, dropdown=100, sticky=200, overlay=300, modal=400, toast=500, tooltip=600

**Icons:** Lucide library, 20px default (16px inline, 24px prominent), 1.5px stroke

## Dark Mode

Three activation methods, same tokens:

| Method | Selector | Use case |
|--------|----------|----------|
| `.m-dark` | On any container | Scoped panels (code areas, chart sections) |
| `.dark` | On `<html>` or `<body>` | Global app toggle (web apps) |
| `@media` | OS preference | Opt-in, commented by default |

Dark token overrides:
- bg: neutral-950 (#0D0F12), surface: neutral-900 (#16191D)
- text: neutral-200 (#E9ECEF), secondary: neutral-400 (#ADB5BD)
- primary: primary-400 (#818CF8), accent: accent-400 (#FBBF24)
- borders: neutral-700 (#343A40)
- shadows: higher opacity (0.2-0.5)

Default to **light theme** unless the user specifies dark.

## Motion

- 120ms fast (hover, toggles)
- 200ms base (standard transitions)
- 300ms slow (panels, modals)
- 250ms ease-out-expo (entering), 150ms ease-in-expo (exiting) — wired to named easing curves (`--m-ease-out-expo`, `--m-ease-in-expo`), not generic `ease-out`/`ease-in`
- **Always** include `@media (prefers-reduced-motion: reduce)` override
- **Never** use looping decorative animations

## Accessibility — Non-Negotiable

- Focus ring: 2px solid primary-600, 2px offset
- Touch targets: ≥ 44×44px
- Color never sole state indicator — always icon + text + color
- All interactive elements keyboard-navigable
- Semantic HTML structure

## Context-Specific Adaptation

**Web apps:** Full component system, 15px base, sidebar 240px + fluid content, max 1280px
**Documentation:** 17px body, 1.7 line-height, 680px prose width, 220px left-nav TOC (`--m-sidebar-docs`), anchor links on headings
**Slide decks:** Scale type 1.5×, code 18px min, max 6 bullets/slide, .m-dark for code slides
**Charts/data viz:** Chart color sequence above, 11px JetBrains Mono axis labels, neutral-100 gridlines
**GitHub:** shields.io badges ?color=4F46E5 (primary) / ?color=B45309 (accent)

## Anti-Patterns — NEVER

- Use Inter, Roboto, Arial, or system-ui as visible font choice
- Purple gradients on white backgrounds
- Rounded corners > 16px (except pills)
- Looping or decorative animations
- Color as sole state indicator
- neutral-500 for body text under 14px
- accent-500/600 as text color on white

## Footnotes

Always include a category-specific footnote in Meridian-styled outputs. Match to deliverable category:

- **Data products:** "Curated chaos by Prasanth Sistla"
- **Dev portfolio:** "Maintained with caffeine by Prasanth Sistla"
- **Landing pages / personal tools / dashboards:** "Created for the curious, by Prasanth Sistla"
- **Architecture / enterprise presentations:** "Built for scale by Prasanth Sistla"
- **High humor:** "99% done, by Prasanth Sistla"

## Reference Files

For exact hex values, full palette, CSS custom properties, and dark mode tokens (v1.2.0):
→ Read `references/tokens.md`

For a portable, copy-paste prompt block (full instruction block, quick-ref, and per-context override snippets for web apps / docs / slides / GitHub / data viz):
→ Read `references/prompt-stem.md`
